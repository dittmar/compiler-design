William Ezekiel
Kevin Dittmar
Joseph Alacqua

Program 9 README

Professor Bergman, below are the directories and files in this folder as well as what they contain.

grammar.txt - our grammar as it currently stands.

Optimization Description.txt - describes the optimizations implemented for our programming language

Optimize Programs(Output) - Optimized versions of the programs in the directory “Unoptimized Programs”

Problems Encountered.txt - describes problems encountered during this program as well as implementations we did not have time to implement.

Unoptimized Programs - directory of programs that are unoptimized.

wolf - the project containing all src files

Changes to Grammar
 - Native Function Flatten removed, _ that used to be use with Flatten now used
	with a new native function Last
 - New Native function Last that returns the last element of a list.



